<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/about', function () {
    return view('about');
});
Route::get('/students', function () {
    return view('students.home');
});
Route::get('/students/{id}', function ($id) {
    echo 'ID:'.$id;
});

